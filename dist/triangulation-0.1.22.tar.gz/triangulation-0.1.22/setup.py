# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['triangulation']

package_data = \
{'': ['*']}

install_requires = \
['GDAL==3.4.3',
 'Pillow==9.1.0',
 'Shapely==1.8.2',
 'imantics==0.1.12',
 'numpy==1.21.6',
 'pycocotools==2.0.4',
 'scipy==1.7.3',
 'tqdm==4.64.0']

setup_kwargs = {
    'name': 'triangulation',
    'version': '0.1.22',
    'description': '',
    'long_description': None,
    'author': 'laurenssam',
    'author_email': 'laurenssamson@hotmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
